import React from 'react'
import './hero.css'


const Hero = () => {
  return (
    <div className='hero'>
      <div className='hero-text'>
        <h1>Karibu Mwananchi</h1>
        <p>Mfumo wa Walipa kodi nchini</p>
        <p>Kama una TIN namba bonyeza hapa chini</p>
        <button className='btn'>
          <a href="login.jsx">Login</a>
        </button>
      </div>
      

    </div>
  )
}

export default Hero